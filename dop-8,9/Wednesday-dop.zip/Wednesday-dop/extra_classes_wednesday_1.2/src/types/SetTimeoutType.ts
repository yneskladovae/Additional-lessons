export type SetTimeoutType = ReturnType<typeof setTimeout>;
